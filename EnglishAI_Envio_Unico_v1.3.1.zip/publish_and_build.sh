#!/usr/bin/env bash
set -euo pipefail

ZIP_PATH="${1:-English-Ai-projeto-v1.3.1-AUDITADO-R2.zip}"
EXPECTED_BRANCH="native-android-1.3-claude-fixes"

if [[ ! -f "$ZIP_PATH" ]]; then
  echo "ERRO: nao encontrei o ZIP: $ZIP_PATH"
  echo "Coloque o ZIP auditado nesta pasta ou passe o caminho como argumento."
  exit 2
fi

BRANCH="$(git branch --show-current)"
if [[ "$BRANCH" != "$EXPECTED_BRANCH" ]]; then
  echo "ERRO: branch atual: $BRANCH"
  echo "Abra o Codespace na branch $EXPECTED_BRANCH antes de executar."
  exit 3
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

unzip -q "$ZIP_PATH" -d "$TMP"
SRC="$TMP/english_ai131"
if [[ ! -f "$SRC/android-native/app/build.gradle.kts" || ! -f "$SRC/tools/static_check.py" ]]; then
  echo "ERRO: a estrutura esperada english_ai131 nao foi encontrada dentro do ZIP."
  exit 4
fi

# Overlay only the project source; never copy the ZIP itself into the repository.
cp -a "$SRC/." .

# Ensure a push to this isolated branch triggers the Android build workflow.
python3 - <<'PY'
from pathlib import Path
p = Path(".github/workflows/android-native.yml")
s = p.read_text(encoding="utf-8")
s = s.replace(
    "branches: [native-android-offline]",
    "branches: [native-android-offline, native-android-1.3-claude-fixes]"
)
if "native-android-1.3-claude-fixes" not in s:
    raise SystemExit("Nao consegui adicionar a branch isolada ao gatilho do workflow.")
p.write_text(s, encoding="utf-8")
PY

echo
echo "== Verificacoes estaticas =="
python3 tools/static_check.py

echo
echo "== Sintaxe do JavaScript inline =="
python3 - <<'PY'
import re
from pathlib import Path
h = Path("android-native/app/src/main/assets/www/index.html").read_text(encoding="utf-8")
scripts = re.findall(r"<script(?:\s[^>]*)?>([\s\S]*?)</script>", h, re.IGNORECASE)
if len(scripts) != 1:
    raise SystemExit(f"Esperava um script inline; encontrei {len(scripts)}.")
Path("/tmp/english-ai-inline-check.js").write_text(scripts[0], encoding="utf-8")
PY
node --check /tmp/english-ai-inline-check.js

echo
echo "== Versao do projeto =="
grep -E 'versionCode|versionName' android-native/app/build.gradle.kts

echo
echo "== Commit e envio da branch =="
git add .github/workflows/android-native.yml android-native index.html manifest.json tools icon-192.png icon-512.png icon-maskable-512.png
git status --short
git commit -m "Apply audited English AI v1.3 fixes from Claude"
git push origin "$EXPECTED_BRANCH"

echo
echo "ENVIADO. Abra a aba Actions do repositorio e acompanhe 'Build English Ai native Android'."
echo "Baixe o artefato English-Ai-Native-debug-apk somente se o job e a verificacao de versao passarem."
